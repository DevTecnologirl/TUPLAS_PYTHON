# Cria um novo dicionário
d = {}
# Cria uma chave por associoação
d['parrot'] = 'Papagaio'
d['cat'] = 'Gato'
d['dog'] = 'Cachorro'
d['fish'] = 'Peixe'
d['bird'] = 'Pássaro'
print(d)