# Cria um dicionário com {} e : que significa uma chave e um valor
dicionario = {'chave1':'valor1','chave2':'valor2'}
print(dicionario['chave2'])