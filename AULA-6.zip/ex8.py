dicionarioInglesPortugues = {'dog':'cachorro','cat':'gato'}
print(dicionarioInglesPortugues['cat'])
print(dicionarioInglesPortugues['dog'])