# Cria um novo dicionário
d = {}
# Cria uma chave por associoação
d['parrot'] = 'Papagaio'
d['cat'] = 'Gato'
d['dog'] = 'Cachorro'
d['fish'] = 'Peixe'
d['bird'] = 'Pássaro'
#print(d)
# Retorna uma lista de todas as chaves
#print(d.keys())
# Pega todos os valores
#print(d.values())
# Método para retornar as tuplas de todos os itens (aprenderemos sobre as tuplas em breve)
#print(d.items())