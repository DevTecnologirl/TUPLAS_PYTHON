a = True
b = False
c = 1 < 2
d = 7 > 10
e = 5 == 5
f = 5 != 5
g = 'a' == 'a'
h = 'a' != 'b'
i = 'a' < 'b'
j = None
print(a, b, c, d, e, f, g, h, i, j)