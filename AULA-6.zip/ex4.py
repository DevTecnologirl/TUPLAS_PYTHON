# Criando uma lista em vez de uma tupla
t = [1, 2, 3, 3, 2, 1, 4, 5, 6, 7, 4, 3, 2]

# Alterando o primeiro valor da lista
t[0] = 'novo valor'

# Adicionando um valor no final da lista
t.append(5)

# Removendo o último valor da lista
t.pop()

# Removendo a primeira ocorrência do valor 2
t.remove(2)
