# Você também pode variar os tipos de dados
t = ('um', 2, 'três',True, 4.5 , 'cinco', False)
print(t[2])
print(t[2:5])