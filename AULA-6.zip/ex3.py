t = (1, 2, 3, 3, 2, 1, 4, 5, 6, 7, 4, 3, 2)
# O método len() funciona também para tuplas
print (len(t))
# Use .index com o valor de parâmetro para retornar o índice do mesmo
print (t.index(7))
# Use .count() para saber quantas vezes determinado item apareceu na tupla
print (t.count(2))
